package mypkg;

public class MyException extends Exception {
    public MyException(String m) {
        super(m);
    }
}
